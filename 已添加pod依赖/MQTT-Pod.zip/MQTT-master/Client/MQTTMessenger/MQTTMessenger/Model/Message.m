//
//  Message.m
//  MQTTMessenger
//
//  Created by 王 松 on 14-1-17.
//  Copyright (c) 2014年 Song.Wang. All rights reserved.
//

#import "Message.h"


@implementation Message

@dynamic from;
@dynamic message;
@dynamic timestamp;
@dynamic to;

@end
