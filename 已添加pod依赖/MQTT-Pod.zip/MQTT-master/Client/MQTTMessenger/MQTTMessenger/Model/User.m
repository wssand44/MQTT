//
//  User.m
//  MQTTMessenger
//
//  Created by 王 松 on 14-1-17.
//  Copyright (c) 2014年 Song.Wang. All rights reserved.
//

#import "User.h"


@implementation User

@dynamic name;
@dynamic userId;

@end
